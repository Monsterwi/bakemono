import json,statistics
from pathlib import Path
r=Path(__file__).parent
out={'source_commit':'77e5186','baseline_commit':'e1b158a','rate':{},'saturation':{},'functional':{},'compatibility':{},'large':{}}
med=statistics.median
sat=json.loads((r/'delivery-saturation/summary.json').read_text())
for v in ('baseline','optimized'):
 out['saturation'][v]={}
 for c in (32,100):
  a=[x for x in sat if x['variant']==v and x['concurrency']==c]
  out['saturation'][v][c]={'rounds':len(a),'qps':med(x['requests_per_second'] for x in a),'p99_ms':med(x['completion_ms']['p99'] for x in a),'cpu_us_request':med(x['cpu_seconds_per_gib']*1e6/4096 for x in a),'rss_mib':med(x['rss_peak_bytes']/(1<<20) for x in a),'errors':sum(x['unexpected_errors'] for x in a)}
 a=[]
 for p in sorted(r.glob(f'delivery-{v}-rate-*/summary.json')):a+=json.loads(p.read_text())
 rates={}
 for rate in (12000,16000):
  b=[x for x in a if x['rate']==rate]
  if not b:continue
  rates[rate]={'rounds':len(b),'successful':sum(x['successful'] for x in b),'errors':sum(x['errors'] for x in b),'dropped':sum(x['dropped'] for x in b),'cpu_us_request':med(x['cpu_us_request'] for x in b),'rss_mib':med(x['rss_peak_bytes']/(1<<20) for x in b)}
  for metric in ('queue_ms','ttfb_ms','first_body_ms','completion_ms'):
   rates[rate][metric]={q:med(x[metric][q] for x in b) for q in ('p50','p95','p99')}
 out['rate'][v]=rates
for label in ('delivery-functional-ssd1','delivery-functional-data3','delivery-functional-s3fifo'):
 p=r/label/'functional.json'
 if p.exists():
  a=json.loads(p.read_text());out['functional'][label]={'passed':sum(x['passed'] for x in a),'total':len(a)}
for kind in ('compat200','upgrade'):
 for medium in ('ssd1','data3'):
  p=r/f'delivery-{kind}-{medium}'/(kind+'.json')
  if p.exists():out['compatibility'][f'{kind}-{medium}']=json.loads(p.read_text())
for label in ('baseline-final-large','delivery-large'):
 p=r/label/'summary.json'
 if p.exists():
  a=json.loads(p.read_text());out['large'][label]={}
  for c in (8,32):
   b=[x for x in a if x['concurrency']==c]
   out['large'][label][c]={'mib_per_second':med(x['mib_per_second'] for x in b),'cpu_s_gib':med(x['cpu_seconds_per_gib'] for x in b),'rss_mib':med(x['rss_peak_bytes']/(1<<20) for x in b)}
out['large_paired']={}
a=json.loads((r/'delivery-large-paired/summary.json').read_text())
for v in ('baseline','optimized'):
 out['large_paired'][v]={}
 for c in (8,32):
  b=[x for x in a if x['variant']==v and x['concurrency']==c]
  assert len(b)==3 and all(x['unexpected_errors']==0 for x in b)
  out['large_paired'][v][c]={'rounds':3,'mib_per_second':med(x['mib_per_second'] for x in b),'cpu_s_gib':med(x['cpu_seconds_per_gib'] for x in b),'rss_mib':med(x['rss_peak_bytes']/(1<<20) for x in b),'errors':0}
assert all(x['rounds']==3 for v in out['rate'].values() for x in v.values())
assert len(out['functional'])==3 and all(x['passed']==x['total']==14 for x in out['functional'].values())
assert len(out['compatibility'])==4 and all(x['success'] for x in out['compatibility'].values())
(r/'delivery-summary.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))

import tarfile,json,hashlib
from pathlib import Path
r=Path('/data/bakemono-lab/perf-29')
manifest=json.loads((r/'delivery-manifest.json').read_text())
manifest['binaries']={k:v for k,v in manifest['binaries'].items() if k in ('baseline-bin','delivery-bin','delivery-profile-bin','hotload-real')}
manifest['diagnostic_baseline']='e1b158a; earlier same-day pinned 16k-RPS control'
(r/'delivery-manifest-final.json').write_text(json.dumps(manifest,indent=2))
selected=[]
for p in sorted(r.iterdir()):
 if p.is_dir() and (p.name.startswith('delivery-') or p.name in ('baseline-diagnostic','baseline-final-large','large-profile-baseline','large-profile-optimized')):
  selected.extend(q for q in p.rglob('*') if q.is_file() and (q.suffix in ('.json','.jsonl','.config','.pprof') or q.name in ('process.log','error.log','trace.out')))
 elif p.is_file() and (p.name.startswith('delivery-') and p.suffix in ('.json','.log') or p.name in ('run_delivery.py','delivery_summary.py','delivery_saturation.py','delivery_large_paired.py','large_profile.py','evaluate.py','topology.csv','baseline-pinned','delivery-pinned','delivery-profile-pinned','baseline-profile-pinned','hey-pinned')):
  selected.append(p)
selected.extend(r/'source/tools'/name for name in ('acceptance.py','ats_comparison.py','hey_benchmark.py'))
assert all(p.exists() for p in selected)
with tarfile.open(r/'delivery-evidence.tar.gz','w:gz') as out:
 for p in sorted(set(selected)):out.add(p,arcname=str(p.relative_to(r)),recursive=False)
print(len(set(selected)),(r/'delivery-evidence.tar.gz').stat().st_size)

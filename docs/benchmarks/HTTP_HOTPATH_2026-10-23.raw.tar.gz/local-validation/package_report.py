import json,tarfile,io,subprocess
from pathlib import Path
r=Path('/workspace/razor-perf-29-artifacts');out=Path('/workspace/razor-perf-next/docs/benchmarks')
s=json.loads((r/'delivery-summary.json').read_text())
s['earlier_non_interleaved_large']=s.pop('large')
s['methods']={'date':'2026-10-23','protocol':'HTTP/1.1 loopback, no TLS','go':'1.26.10','GOMAXPROCS':8,'saturation':'256KiB, unpinned, C32/C100; B,O,O,B,B,O, 10s each','rate':'256KiB; 12000/16000 offered RPS, 100 workers, 20s, 3 rounds; B/O, O/B, B/O','large':'100MiB, pinned, C8/C32; B,O,O,B,B,O, 10s each','pinned_server_cpus':'0,2,4,6,8,10,12,14','pinned_client_cpus':'1,3,5,7,9,11,13,15','aggregation':'median of per-round measurements, not pooled latency percentiles'}
s['local_validation']={'normal':'passed','race_GOFLAGS':'passed','vet':'passed','tool_tests':20,'remote_CI':'pending push authorization'}
s['metadata_open_allocations']={'baseline':130,'optimized':17,'scope':'OpenReadCommitted + LoadHTTPInfo + Close; warm single RAM entry'}
(out/'HTTP_HOTPATH_2026-10-23.json').write_text(json.dumps(s,indent=2)+'\n')
with tarfile.open(r/'delivery-evidence.tar.gz','r:gz') as src,tarfile.open(out/'HTTP_HOTPATH_2026-10-23.raw.tar.gz','w:gz') as dst:
 for m in src.getmembers():
  if not m.isfile():continue
  dst.addfile(m,src.extractfile(m))
 for name in ('77e5186-normal.log','77e5186-race.log','77e5186-vet.log','77e5186-tools.log','baseline-allocations.log','metadata-allocations.log','policy-clock-red.log','profile_probe.go','archive_delivery.py','package_report.py'):
  dst.add(r/name,arcname='local-validation/'+name,recursive=False)
 for p in (r/'profiles').rglob('*'):
  if p.relative_to(r/'profiles').parts[0] in ('baseline','delivery','large-baseline','large-optimized') and p.is_file() and (p.suffix=='.txt' or p.name in ('trace-gc-summary.json','sched.pprof')):
   dst.add(p,arcname='analysis/'+str(p.relative_to(r/'profiles')),recursive=False)
 info='Measured code 77e5186 vs e1b158a. delivery-large-paired is the primary large-file comparison. Earlier non-interleaved data is retained for audit only. Rebuild production from Git; diagnostic build adds local-validation/profile_probe.go only. Replace machine-specific absolute lab paths before replay. No binaries or cache files are included. Remote CI has not run.\n'
 m=tarfile.TarInfo('EVIDENCE.txt');b=info.encode();m.size=len(b);dst.addfile(m,io.BytesIO(b))
print((out/'HTTP_HOTPATH_2026-10-23.raw.tar.gz').stat().st_size)

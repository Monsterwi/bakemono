//go:build razorprofile

package main

import (
 "net/http"
 _ "net/http/pprof"
 "os"
 "runtime"
)

func init() {
 if address := os.Getenv("RAZOR_PROFILE_ADDR"); address != "" {
  runtime.SetMutexProfileFraction(5)
  runtime.SetBlockProfileRate(1000000)
  go func() { if err := http.ListenAndServe(address, nil); err != nil { panic(err) } }()
 }
}

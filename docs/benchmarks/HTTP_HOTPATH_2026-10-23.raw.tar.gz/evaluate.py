import sys,json,os,time,threading,subprocess,statistics
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
root=Path(__file__).parent
sys.path.insert(0,str(root/'source/tools'))
from ats_comparison import Origin,Product,Client,hot,MIB,save,correctness
old=Path('/data/bakemono-lab/build/ats-compare-20261022T095324Z')
fixtures={(s,v):old/'fixtures100'/f'{s}-v{v}.bin' for s in ('small','large') for v in (1,2)}
label,mode,binary=sys.argv[1:4]
medium=sys.argv[4] if len(sys.argv)>4 else 'ssd1'
out=root/label;out.mkdir()
a=SimpleNamespace(binary=Path(binary),hey=(old/'hey-checked' if os.environ.get('UNPINNED') else root/'hey-pinned'),cache_root=Path('/'+medium+'/bakemono-lab/cache/perf-29')/label,public_static=True,block_bytes=MIB,ram_algorithm=os.environ.get('RAM_ALGORITHM','otter'),ram_bytes=10*MIB,seconds=int(os.environ.get('PERF_SECONDS','15')),repeats=1,variant='razor')
a.cache_root.mkdir(parents=True)
rows=[]
with ExitStack() as cleanup:
 origin=Origin(fixtures,out/'origin.json');cleanup.callback(origin.close)
 client=Client(fixtures,out);cleanup.callback(client.raw.close)
 product=Product('razor',out/'server',origin,a);cleanup.callback(product.stop)
 if mode=='correctness':
  checks=correctness(client,product,origin,a)
  assert all(x['passed'] for x in checks),checks
 elif mode=='profile':
  import urllib.request
  client.checked(product,'/small-hot')
  def capture():
   base='http://127.0.0.1:19060/debug/pprof/'
   for endpoint,name in [('profile?seconds=20','cpu.pprof'),('trace?seconds=3','trace.out'),('mutex','mutex.pprof'),('block','block.pprof'),('heap','heap.pprof'),('allocs','allocs.pprof')]:
    (out/name).write_bytes(urllib.request.urlopen(base+endpoint,timeout=30).read())
  capture_thread=threading.Thread(target=capture);capture_thread.start()
  result=subprocess.check_output([str(root/'hotload'),'-url',f'http://127.0.0.1:{product.port}/small-hot','-rate','16000','-seconds','26','-workers','100'],text=True,timeout=80)
  capture_thread.join()
  save(out/'load.json',json.loads(result))
 elif mode=='hot':
  for c in (32,100):
   for rep in range(3):
    row=hot(client,product,origin,a,'small',c,rep);rows.append(row);save(out/'summary.json',rows)
    print(label,c,rep,row['requests_per_second'],row['completion_ms']['p99'],flush=True)
 elif mode=='large':
  for c in (8,32):
   for rep in range(3):
    row=hot(client,product,origin,a,'large',c,rep);rows.append(row);save(out/'summary.json',rows)
    print(label,c,rep,row['mib_per_second'],flush=True)
 elif mode=='upgrade':
  for path in ('/small-upgrade','/large-upgrade'): client.checked(product,path)
  before=origin.snapshot()
  product.stop()
  product.command[0]=os.environ['UPGRADE_BINARY']
  product.start()
  for path in ('/small-upgrade','/large-upgrade'): client.checked(product,path)
  client.checked(product,'/large-upgrade',headers={'Range':'bytes=1048576-3145727'},status=206,expected=client.expected('/large-upgrade',bounds=(MIB,3*MIB-1)))
  assert origin.snapshot()==before
  save(out/'upgrade.json',{'success':True,'origin_unchanged':True})
 elif mode=='compat200':
  files={(s,v):old/'fixtures200'/f'{s}-v{v}.bin' for s in ('small','large') for v in (1,2)}
  assert all(p.exists() for p in files.values())
  origin.fixtures=files
  client.fixtures=files
  client.checked(product,'/large-compat200')
  before=origin.snapshot()
  client.checked(product,'/large-compat200')
  client.checked(product,'/large-compat200',headers={'Range':'bytes=1048576-3145727'},status=206,expected=client.expected('/large-compat200',bounds=(MIB,3*MIB-1)))
  assert origin.snapshot()==before
  save(out/'compat200.json',{'success':True,'origin_unchanged_on_hit':True})
 elif mode=='rate':
  client.checked(product,'/small-hot')
  for rate in (12000,16000):
   before,initial=origin.snapshot(),product.resource()
   done=threading.Event();samples=[initial]
   def sample():
    while not done.wait(.2): samples.append(product.resource())
   monitor=threading.Thread(target=sample);monitor.start()
   try:
    raw=subprocess.check_output([str(root/'hotload'),'-url',f'http://127.0.0.1:{product.port}/small-hot','-rate',str(rate),'-seconds',str(a.seconds),'-workers','100'],text=True,timeout=a.seconds+90)
   finally:
    done.set();monitor.join()
   samples.append(product.resource())
   result=json.loads(raw)
   result['cpu_us_request']=(samples[-1]['cpu_seconds']-initial['cpu_seconds'])*1e6/result['successful']
   result['rss_peak_bytes']=max(x['rss_bytes'] for x in samples)
   result['resource_samples']=samples
   result['origin_before'],result['origin_after']=before,origin.snapshot()
   assert result['origin_before']==result['origin_after']
   rows.append(result);save(out/'summary.json',rows)
   print(label,rate,{k:v for k,v in result.items() if k not in ('resource_samples','origin_before','origin_after')},flush=True)
 else: raise ValueError(mode)

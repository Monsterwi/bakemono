import os,subprocess,json,hashlib
from pathlib import Path
r=Path('/data/bakemono-lab/perf-29');python='/data/bakemono-lab/opt/python-3.12.13/bin/python3.12'
cpus='0,2,4,6,8,10,12,14'
for name,binary in [('delivery-pinned','delivery-bin'),('delivery-profile-pinned','delivery-profile-bin')]:
 p=r/name;p.write_text(f'#!/bin/sh\nexec taskset -c {cpus} {r/binary} "$@"\n');p.chmod(0o755)
manifest=json.loads((r/'final-manifest.json').read_text())
manifest['source_commit']='77e5186'
manifest['binaries'].update({name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in ('delivery-bin','delivery-profile-bin')})
(r/'delivery-manifest.json').write_text(json.dumps(manifest,indent=2))
jobs=[]
subprocess.run([python,str(r/'delivery_saturation.py')],env=dict(os.environ,GOMAXPROCS='8'),check=True)
for index,order in enumerate((('baseline','optimized'),('optimized','baseline'),('baseline','optimized')),1):
 for v in order:jobs.append((f'delivery-{v}-rate-{index}','rate','baseline-pinned' if v=='baseline' else 'delivery-pinned','ssd1',20,False))
for media in ('ssd1','data3'):
 jobs.append((f'delivery-functional-{media}','correctness','delivery-pinned',media,5,False))
jobs.append(('delivery-functional-s3fifo','correctness','delivery-pinned','ssd1',5,False))
jobs.append(('delivery-large','large','delivery-pinned','ssd1',5,False))
jobs.append(('delivery-diagnostic','profile','delivery-profile-pinned','ssd1',26,False))
for media in ('ssd1','data3'):
 jobs.append((f'delivery-compat200-{media}','compat200','delivery-pinned',media,5,False))
 jobs.append((f'delivery-upgrade-{media}','upgrade','baseline-pinned',media,5,False))
for label,mode,binary,medium,seconds,unpinned in jobs:
 env=dict(os.environ,PERF_SECONDS=str(seconds),GOMAXPROCS='8')
 if unpinned:env['UNPINNED']='1'
 if label.endswith('s3fifo'):env['RAM_ALGORITHM']='s3-fifo'
 if mode=='profile':env['RAZOR_PROFILE_ADDR']='127.0.0.1:19060'
 # Upgrade mode uses this pointer only to switch the fresh experimental cache.
 if mode=='upgrade':
  env['UPGRADE_BINARY']=str(r/'delivery-pinned')
 with (r/f'{label}.log').open('w') as log:
  result=subprocess.run([python,str(r/'evaluate.py'),label,mode,str(r/binary),medium],env=env,stdout=log,stderr=subprocess.STDOUT)
 print(label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)

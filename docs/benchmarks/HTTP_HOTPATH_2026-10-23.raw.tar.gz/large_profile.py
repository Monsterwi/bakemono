import sys,os
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
r=Path(__file__).parent
sys.path.insert(0,str(r/'source/tools'))
from ats_comparison import Origin,Product,Client,hot,MIB,save
old=Path('/data/bakemono-lab/build/ats-compare-20261022T095324Z')
fixtures={(s,v):old/'fixtures100'/f'{s}-v{v}.bin' for s in ('small','large') for v in (1,2)}
import threading,urllib.request
for v,binary in [('baseline','baseline-profile-pinned'),('optimized','delivery-profile-pinned')]:
 out=r/('large-profile-'+v);out.mkdir()
 with ExitStack() as cleanup:
  origin=Origin(fixtures,out/'origin.json');cleanup.callback(origin.close)
  a=SimpleNamespace(binary=r/binary,hey=r/'hey-pinned',cache_root=Path('/ssd1/bakemono-lab/cache/perf-29')/out.name,public_static=True,block_bytes=MIB,ram_algorithm='otter',ram_bytes=10*MIB,seconds=26)
  a.cache_root.mkdir(parents=True)
  client=Client(fixtures,out);cleanup.callback(client.raw.close)
  product=Product('razor',out/'server',origin,a);cleanup.callback(product.stop)
  client.checked(product,'/large-hot')
  def capture():
   base='http://127.0.0.1:19060/debug/pprof/'
   for endpoint,name in [('profile?seconds=20','cpu.pprof'),('allocs','allocs.pprof')]:
    (out/name).write_bytes(urllib.request.urlopen(base+endpoint,timeout=30).read())
  thread=threading.Thread(target=capture);thread.start()
  row=hot(client,product,origin,a,'large',8,0);thread.join();save(out/'summary.json',[row])
  print(v,row['mib_per_second'],flush=True)

import sys,os
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
r=Path(__file__).parent
sys.path.insert(0,str(r/'source/tools'))
from ats_comparison import Origin,Product,Client,hot,MIB,save
old=Path('/data/bakemono-lab/build/ats-compare-20261022T095324Z')
fixtures={(s,v):old/'fixtures100'/f'{s}-v{v}.bin' for s in ('small','large') for v in (1,2)}
out=r/'delivery-saturation';out.mkdir()
with ExitStack() as cleanup:
 origin=Origin(fixtures,out/'origin.json');cleanup.callback(origin.close)
 products,clients,args={},{},{}
 for variant,binary in [('baseline','baseline-bin'),('optimized','delivery-bin')]:
  d=out/variant;d.mkdir()
  a=SimpleNamespace(binary=r/binary,hey=old/'hey-checked',cache_root=Path('/ssd1/bakemono-lab/cache/perf-29/delivery-saturation')/variant,public_static=True,block_bytes=MIB,ram_algorithm='otter',ram_bytes=10*MIB,seconds=10)
  a.cache_root.mkdir(parents=True)
  client=Client(fixtures,d);cleanup.callback(client.raw.close)
  product=Product('razor',d/'server',origin,a);cleanup.callback(product.stop)
  client.checked(product,'/small-hot')
  products[variant],clients[variant],args[variant]=product,client,a
 rows=[]
 for c in (32,100):
  repeats={'baseline':0,'optimized':0}
  for v in ('baseline','optimized','optimized','baseline','baseline','optimized'):
   row=hot(clients[v],products[v],origin,args[v],'small',c,repeats[v]);repeats[v]+=1
   row['variant']=v;rows.append(row);save(out/'summary.json',rows)
   print(v,c,row['requests_per_second'],row['completion_ms']['p99'],flush=True)

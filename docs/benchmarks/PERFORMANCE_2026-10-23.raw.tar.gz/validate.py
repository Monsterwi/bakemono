import sys
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
sys.path.insert(0,str(Path(__file__).parent/'source/tools'))
from ats_comparison import Origin,Product,Client,hot,correctness,MIB,save
root=Path(__file__).parent.resolve()
old=Path('/data/bakemono-lab/build/ats-compare-20261022T095324Z')
fixtures={(s,v):old/'fixtures100'/f'{s}-v{v}.bin' for s in ('small','large') for v in (1,2)}
for media,mount in [('ssd','/ssd1'),('hdd','/data3')]:
 for label,binary in [('baseline',old/'razor-193fe7d'),('optimized5',root/'step5')]:
  out=root/f'accept-{media}-{label}';
  if out.exists() and (out/'outcome.json').exists(): continue
  out.mkdir()
  a=SimpleNamespace(binary=binary,hey=old/'hey-checked',cache_root=Path(mount)/'bakemono-lab/cache/perf-20261023'/out.name,public_static=True,block_bytes=MIB,ram_algorithm='otter',ram_bytes=10*MIB,seconds=5,repeats=3,variant="razor")
  a.cache_root.mkdir(parents=True)
  with ExitStack() as cleanup:
   origin=Origin(fixtures,out/'origin.json');cleanup.callback(origin.close)
   client=Client(fixtures,out);cleanup.callback(client.raw.close)
   product=Product('razor',out/'server',origin,a);cleanup.callback(product.stop)
   if label=='optimized5':
    checks=correctness(client,product,origin,a)
    assert all(r['passed'] for r in checks),checks
   rows=[]
   for c in (8,32):
    for rep in range(3):
     row=hot(client,product,origin,a,'large',c,rep);rows.append(row)
     save(out/'summary.json',rows)
     print(out.name,c,rep,round(row['mib_per_second'],2),flush=True)
   save(out/'outcome.json',{'success':True,'functional':len(checks) if label=='optimized5' else None})

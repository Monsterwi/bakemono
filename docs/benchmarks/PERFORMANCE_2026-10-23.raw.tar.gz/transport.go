package main
import("flag";"os";"strings";"net/http";"strconv";"fmt";"os/signal";"syscall";"context")
func main(){
 c:=flag.String("c","","config");flag.Parse()
 data,err:=os.ReadFile(*c+"/records.config");if err!=nil{panic(err)}
 port:=""
 for _,line:=range strings.Split(string(data),"\n"){f:=strings.Fields(line);if len(f)==4&&f[1]=="proxy.config.http.server_ports"{port=f[3]}}
 body,err:=os.ReadFile("/data/bakemono-lab/build/ats-compare-20261022T095324Z/fixtures100/small-v1.bin");if err!=nil{panic(err)}
 http.HandleFunc("/",func(w http.ResponseWriter,r *http.Request){w.Header().Set("Content-Length",strconv.Itoa(len(body)));w.Write(body)})
 srv:=&http.Server{Addr:"127.0.0.1:"+port}; stop:=make(chan os.Signal,1); signal.Notify(stop,syscall.SIGTERM); go func(){ <-stop; srv.Shutdown(context.Background()) }(); if err:=srv.ListenAndServe();err!=http.ErrServerClosed{fmt.Println(err)}
}

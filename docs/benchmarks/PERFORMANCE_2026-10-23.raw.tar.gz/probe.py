import sys,json,os,threading,urllib.request
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
sys.path.insert(0,str(Path(__file__).parent/'source/tools'))
from ats_comparison import Origin,Product,Client,hot,MIB,save,ATS10
root=Path(__file__).parent
old=Path('/data/bakemono-lab/build/ats-compare-20261022T095324Z')
label=sys.argv[1]
a=SimpleNamespace(binary=Path(sys.argv[2]),hey=old/'hey-checked',cache_root=Path('/ssd1/bakemono-lab/cache/perf-20261023')/label,public_static=True,block_bytes=MIB,ram_algorithm='otter',ram_bytes=10*MIB,seconds=5,ats_prefix=Path('/data/bakemono-lab/opt/ats-10.2.1-ats-compare-20261022T095324Z'),ats_env=Path('/data/bakemono-lab/opt/ats-build-env-ats-compare-20261022T095324Z'),ats_prefetch=1)
out=root/label
out.mkdir()
a.cache_root.mkdir(parents=True)
fixtures={(s,v):old/'fixtures100'/f'{s}-v{v}.bin' for s in ('small','large') for v in (1,2)}
with ExitStack() as cleanup:
 origin=Origin(fixtures,out/'origin.json');cleanup.callback(origin.close)
 client=Client(fixtures,out);cleanup.callback(client.raw.close)
 product=ATS10(out/'server',origin,a,'ats-native') if label.startswith('ats') else Product('razor',out/'server',origin,a)
 cleanup.callback(product.stop)
 rows=[]
 if 'profile' in label:
  a.seconds=30
  client.checked(product,'/small-hot')
  def capture():
   url='http://127.0.0.1:19060/debug/pprof/'
   for endpoint,name in [('profile?seconds=25','cpu'),('mutex','mutex'),('block','block'),('allocs','allocs'),('heap','heap')]:
    (out/(name+'.pprof')).write_bytes(urllib.request.urlopen(url+endpoint,timeout=40).read())
  probe=threading.Thread(target=capture);probe.start()
 for c in ((32,) if 'profile' in label else tuple(map(int,os.environ.get('PERF_CONCURRENCY','1,8,32,100').split(',')))):
  for rep in range(1 if 'profile' in label else 3):
   row=hot(client,product,origin,a,'small',c,rep);rows.append(row)
   print(label,c,rep,round(row['requests_per_second'],2) if 'requests_per_second' in row else row,flush=True)
   save(out/'summary.json',rows)

 if 'profile' in label: probe.join()

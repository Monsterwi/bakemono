import os,subprocess
from pathlib import Path
root=Path(__file__).parent.resolve()
py='/data/bakemono-lab/opt/python-3.12.13/bin/python3.12'
old=Path('/data/bakemono-lab/build/ats-compare-20261022T095324Z')
env=dict(os.environ,LC_ALL='C',PERF_CONCURRENCY='32,100')
for label,binary in [('baseline-repeat',old/'razor-193fe7d'),('ats-repeat',old/'razor-193fe7d'),('step5-repeat',root/'step5'),('transport-control',root/'transport2')]:
 subprocess.run([py,str(root/'probe.py'),label,str(binary)],env=env,check=True)
env['RAZOR_PROFILE_ADDR']='127.0.0.1:19060'
subprocess.run([py,str(root/'probe.py'),'step5-profile-run',str(root/'step5-profile')],env=env,check=True)
env.pop('RAZOR_PROFILE_ADDR')
for media,mount in [('ssd','/ssd1'),('hdd','/data3')]:
 cmd=[py,str(root/'source/tools/ats_comparison.py'),'--binary',str(root/'step5'),'--hey',str(old/'hey-checked'),'--fixtures',str(old/'fixtures200'),'--output',str(root/('compat200-'+media)),'--cache-root',mount+'/bakemono-lab/cache/perf-20261023/compat200','--ats-prefix','/data/bakemono-lab/opt/ats-10.2.1-ats-compare-20261022T095324Z','--ats-env','/data/bakemono-lab/opt/ats-build-env-ats-compare-20261022T095324Z','--variant','razor','--source-commit','e1b158a','--compat-only']
 subprocess.run(cmd,env=env,check=True)
 print('COMPAT',media,'PASS',flush=True)
subprocess.run([py,str(root/'check_gap.py'),'step5-repeat','ats-repeat'],check=True)

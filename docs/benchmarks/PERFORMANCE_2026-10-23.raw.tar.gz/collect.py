import json,statistics,hashlib,tarfile,subprocess,os
from pathlib import Path
root=Path(__file__).parent.resolve()
os.environ.update(GOROOT=str(root/'go'),GOCACHE=str(root/'go-cache'))
for kind in ('cpu','mutex','block','allocs','heap'):
 for fmt in (('txt','svg') if kind in ('cpu','mutex') else ('txt',)):
  cmd=[str(root/'go/bin/go'),'tool','pprof','-top' if fmt=='txt' else '-svg','-nodecount=50']
  if kind=='allocs': cmd+=['-sample_index=alloc_space']
  cmd += [str(root/'step5-profile'),str(root/'step5-profile-run'/f'{kind}.pprof')]
  with (root/'step5-profile-run'/f'{kind}.{fmt}').open('w') as out: subprocess.run(cmd,stdout=out,check=True)
result={'source_commit':'e1b158a','baseline_commit':'193fe7d','measurements':{},'functional':{},'binaries':{},'limitations':['loopback HTTP/1.1; no TLS; powersave governor; no affinity; other host processes present','three 5-second rounds per group; profiles are separate 25-second captures','hot large reads include page cache; not a physical disk benchmark','transport control omits cache, CRC, logging, admission and HTTP cache semantics']}
for path in sorted(root.glob('*/summary.json')):
 rows=json.loads(path.read_text());out={}
 for c in sorted(set(x['concurrency'] for x in rows)):
  group=[x for x in rows if x['concurrency']==c]
  points=[]
  for x in group:
   points.append(dict(qps=x['requests_per_second'],mib_s=x['mib_per_second'],p99_ms=x['completion_ms'].get('p99'),cpu_s_gib=x['cpu_seconds_per_gib'],cpu_cores=x['cpu_seconds_per_gib']*x['mib_per_second']/1024,rss_mib=x['rss_peak_bytes']/1048576,requests=x['requests'],origin=x['origin'],io=x['process_io_bytes'],errors=x['unexpected_errors']))
  med={k:statistics.median(x[k] for x in points if x[k] is not None) for k in ('qps','mib_s','cpu_s_gib','cpu_cores','rss_mib')}
  vals=[x['p99_ms'] for x in points if x['p99_ms'] is not None];med['p99_ms']=statistics.median(vals) if vals else None
  out[str(c)]={'median':med,'rounds':points}
 result['measurements'][path.parent.name]=out
for path in root.glob('*/functional.json'):result['functional'][path.parent.name]=json.loads(path.read_text())
for name in ('step1','step2','step3','step4','step5','baseline-profile','final-profile','step5-profile','transport2'):
 f=root/name;result['binaries'][name]=hashlib.sha256(f.read_bytes()).hexdigest()
result['excluded_runs']={'transport-run':'all throughput samples completed, but temporary transport control exited SIGTERM -15; replaced by transport-control with clean shutdown','accept-ssd-optimized':'only first four checks completed; missing args.repeats in temporary harness; replaced by optimized5','step4-run':'binary relative path failed before requests; replaced by step4-measured'}
result['environment']={'go':'1.26.10','ats':'10.2.1','gomaxprocs':8,'ats_network_threads':8,'ram_algorithm':'otter','ram_bytes':10485760,'block_bytes':1048576,'kernel':os.uname().release,'machine':os.uname().machine,'cpu_count':os.cpu_count(),'cpu_model':next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),'mem_total':next(line for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemTotal:')),'governor':Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip()}
(root/'report.json').write_text(json.dumps(result,indent=2)+'\n')
include=[]
for d in root.iterdir():
 if d.is_dir() and ((d/'summary.json').exists() or (d/'outcome.json').exists() or (d/'functional.json').exists()):
  for f in d.rglob('*'):
   if f.is_file() and (f.suffix in ('.json','.jsonl','.pprof','.svg','.txt') or f.name in ('records.config','storage.config')): include.append(f)
include += [f for f in root.iterdir() if f.is_file() and f.suffix in ('.py','.go','.log')]
include += [root/'report.json',root/'source/profile_probe.go']
for name in ('ats_comparison.py','acceptance.py','hey_benchmark.py'):include.append(root/'source/tools'/name)
with tarfile.open(root/'evidence.tar.gz','w:gz') as tar:
 for f in sorted(set(include)):tar.add(f,arcname=str(f.relative_to(root)))
print('archive_bytes', (root/'evidence.tar.gz').stat().st_size)
for name in ('baseline-repeat','ats-repeat','step5-repeat','transport-control','accept-ssd-baseline','accept-ssd-optimized5','accept-hdd-baseline','accept-hdd-optimized5'):
 print(name, {c:row['median'] for c,row in result['measurements'][name].items()})

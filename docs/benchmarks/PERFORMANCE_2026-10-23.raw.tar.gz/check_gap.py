import json,sys,statistics
from pathlib import Path
root=Path(__file__).parent
left=json.loads((root/sys.argv[1]/'summary.json').read_text())
right=json.loads((root/sys.argv[2]/'summary.json').read_text())
passed=True
for c in (32,100):
 def median(rows): return statistics.median(x['requests_per_second'] for x in rows if x['concurrency']==c)
 ratio=median(left)/median(right)
 print(f'C{c}: Razor/ATS={ratio:.3f}, minimum=0.500')
 passed &= ratio>=.5
sys.exit(0 if passed else 1)

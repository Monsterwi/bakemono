import sys,os,json,time,hashlib,statistics
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
root=Path(__file__).parent
sys.path.insert(0,str(root/'source/tools'))
from ats_comparison import ATS10,Origin,Product,Client,hot,MIB,save,file_hash
lab=Path('/data/bakemono-lab')
old=lab/'build/ats-compare-20261022T095324Z'
run='hot-8581267-20261024'
out=root/'results';out.mkdir(exist_ok=False)
fixtures={(s,v):old/'fixtures100'/f'{s}-v{v}.bin' for s in ('small','large') for v in (1,2)}
assert all(p.exists() for p in fixtures.values())
hey=old/'hey-checked'
build=json.loads(hey.with_suffix('.build.json').read_text())
assert build['variant']=='razor-bodycheck' and file_hash(hey)==build['sha256']
ats_prefix=lab/'opt/ats-10.2.1-ats-compare-20261022T095324Z'
ats_env=lab/'opt/ats-build-env-ats-compare-20261022T095324Z'
metadata={'source_commit':'85812672199e8e4afbaa45d4106a2fc709453906','ats_version':'10.2.1','start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'binary_sha256':file_hash(root/'razor'),'ats_sha256':file_hash(ats_prefix/'bin/traffic_server'),'hey_build':build,'fixture_sha256':{p.name:file_hash(p) for p in fixtures.values()},'harness_sha256':file_hash(root/'source/tools/ats_comparison.py'),'script_sha256':file_hash(Path(__file__)),'protocol':'HTTP/1.1 loopback keepalive identity; no TLS','object_bytes':256<<10,'server_GOMAXPROCS_or_threads':8,'hey_cpus':8,'affinity':'unpinned','seconds_per_run':10,'rounds':3,'variants':['razor','ats-native','ats-slice'],'medium':'SSD; RAM hot HIT; verify actual read_bytes','cache_bytes':1024*MIB,'RAM_bytes':10*MIB,'logging':True,'note':'Three products resident, one load active at a time; rotate order. CRC enabled in Razor, ATS default checksum=0.'}
save(out/'manifest.json',metadata)
with ExitStack() as cleanup:
 origin=Origin(fixtures,out/'origin.json');cleanup.callback(origin.close)
 products,clients,args={},{},{}
 for v in metadata['variants']:
  d=out/(run+'-'+v);d.mkdir()
  a=SimpleNamespace(binary=root/'razor',hey=hey,ats_prefix=ats_prefix,ats_env=ats_env,ats_prefetch=1,cache_root=Path('/ssd1/bakemono-lab/cache')/run/v,public_static=True,block_bytes=MIB,ram_algorithm='otter',ram_bytes=10*MIB,seconds=10)
  a.cache_root.mkdir(parents=True,exist_ok=False)
  client=Client(fixtures,d);cleanup.callback(client.raw.close)
  p=Product('razor',d/'server',origin,a) if v=='razor' else ATS10(d/'server',origin,a,v)
  cleanup.callback(p.stop)
  client.checked(p,'/small-hot')
  products[v],clients[v],args[v]=p,client,a
 rows=[]
 for c in (32,100):
  for rep,order in enumerate((('razor','ats-native','ats-slice'),('ats-native','ats-slice','razor'),('ats-slice','razor','ats-native')),1):
   for v in order:
    row=hot(clients[v],products[v],origin,args[v],'small',c,rep)
    assert row['unexpected_errors']==0,row
    row['variant']=v;rows.append(row);save(out/'hot.json',rows)
    print(v,c,rep,round(row['requests_per_second']),round(row['completion_ms']['p99'],3),flush=True)
med=statistics.median
summary={}
for v in metadata['variants']:
 summary[v]={}
 for c in (32,100):
  a=[x for x in rows if x['variant']==v and x['concurrency']==c]
  assert len(a)==3
  summary[v][c]={'qps':med(x['requests_per_second'] for x in a),'completion_p99_ms':med(x['completion_ms']['p99'] for x in a),'cpu_us_request':med(x['cpu_seconds_per_gib']*1e6/4096 for x in a),'rss_peak_mib':med(x['rss_peak_bytes']/MIB for x in a),'errors':sum(x['unexpected_errors'] for x in a),'requests':sum(x['requests'] for x in a),'origin_requests':sum(x['origin']['requests'] for x in a),'read_bytes':sum(x['process_io_bytes']['read_bytes'] for x in a)}
save(out/'summary.json',{'manifest':metadata,'results':summary})
print(json.dumps(summary,indent=2),flush=True)
